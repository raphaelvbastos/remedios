import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { RemediosPeriodoProvider, RemediosPeriodo } from '../../providers/remedios-periodo/remedios-periodo';
import { RemedioPeriodoPage } from '../../pages/remedio-periodo/remedio-periodo'
/**
 * Generated class for the RemediosPeriodosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-remedios-periodos',
  templateUrl: 'remedios-periodos.html',
})
export class RemediosPeriodosPage {

  lista: any[];
  remediosPeriodos: RemediosPeriodo[];
  constructor(public navCtrl: NavController, public navParams: NavParams, public rpProvider: RemediosPeriodoProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RemediosPeriodosPage');
  }

  ionViewDidEnter() {
    this.rpProvider.getAllPorPeriodo().then(
      (dados: any[]) => this.lista = dados
      //(dados: RemediosPeriodo[]) => this.remediosPeriodos = dados
    ).catch(
      (e) => console.error("Erro lista", JSON.stringify(e))
    );
  }

  incluir(): void {
    this.navCtrl.push(RemedioPeriodoPage);
  }

  editar(id: number): void {
    this.navCtrl.push(RemedioPeriodoPage, {id: id});
  }
}
