import { Injectable } from '@angular/core';
import { SQLiteObject } from '@ionic-native/sqlite';
import { DatabaseProvider } from '../database/database';
import { LocalNotifications } from '@ionic-native/local-notifications';


@Injectable()
export class RemediosPeriodoProvider {

  constructor(private dbProvider: DatabaseProvider, public localNotifications: LocalNotifications) { }

  public insert(remediosPeriodo: RemediosPeriodo) {
    return new Promise((resolve, reject) => {
      this.dbProvider.getDB()
        .then((db: SQLiteObject) => {
          let sql = 'insert into remediosPeriodo (remedio_id, quantidade, periodo_id) values (?, ?, ?)';
          let data = [remediosPeriodo.remedio_id, remediosPeriodo.quantidade, remediosPeriodo.periodo_id];

          db.executeSql(sql, data)
            .then((dados) => resolve(dados))
            .catch((e) => console.error(e));
        })
        .catch((e) => console.error(e));
    });
  }

  public update(remediosPeriodo: RemediosPeriodo) {
    this.notificacao();
    return new Promise((resolve, reject) => {
      this.dbProvider.getDB()
        .then((db: SQLiteObject) => {
          let sql = 'update remediosPeriodo set remedio_id = ?, quantidade = ?, periodo_id = ? where id = ?';
          let data = [remediosPeriodo.remedio_id, remediosPeriodo.quantidade, remediosPeriodo.periodo_id, remediosPeriodo.id];

          db.executeSql(sql, data)
            .then((dados) => resolve(dados))
            .catch((e) => console.error(e));
        })
        .catch((e) => console.error(e));
    });
  }

  public remove(id: number) {
    return new Promise((resolve, reject) => {
      this.dbProvider.getDB()
        .then((db: SQLiteObject) => {
          let sql = 'delete from remediosPeriodo where id = ?';
          let data = [id];

          db.executeSql(sql, data)
            .then((dados) => resolve(dados))
            .catch((e) => console.error(e));
        })
        .catch((e) => console.error(e));
    });
  }

  public get(id: number) {
    return new Promise((resolve, reject) => {
      this.dbProvider.getDB()
        .then((db: SQLiteObject) => {
          let sql = 'SELECT rp.*, r.nome as nome_remedio, p.nome as nome_periodo FROM remediosPeriodo rp ' +
            ' inner join periodos p on rp.periodo_id = p.id ' +
            ' inner join remedios r on rp.remedio_id = r.id ' +
            ' where rp.id = ?';
          let data = [id];

          db.executeSql(sql, data)
            .then((data: any) => {
              let remedioPeriodo = new RemediosPeriodo();
              if (data.rows.length > 0) {
                let item = data.rows.item(0);
                remedioPeriodo.id = item.id;
                remedioPeriodo.remedio_id = item.remedio_id;
                remedioPeriodo.quantidade = item.quantidade;
                remedioPeriodo.periodo_id = item.periodo_id;
              }
              resolve(remedioPeriodo);
            })
            .catch((e) => console.error("erro the", JSON.stringify(e)));
        })
        .catch((e) => console.error("erro select", JSON.stringify(e)));
    });
  }

  public getAll(nomeRemedio: string = null, periodo: number = null) {
    return new Promise((resolve, reject) => {
      this.dbProvider.getDB()
        .then((db: SQLiteObject) => {
          let sql = 'SELECT rp.*, r.nome as nome_remedio, p.nome as nome_perido FROM remediosPeriodo rp ' +
            ' inner join periodos p on rp.periodo_id = p.id ' +
            ' inner join remedios r on rp.remedio_id = r.id ' +
            '  ';
          var data: any[];
          LocalNotifications
          // filtrando pelo nome
          if (nomeRemedio) {
            sql += ' where r.nome like ?'
            data.push('%' + nomeRemedio + '%');
          }

          if (periodo) {
            if (data.length > 0) {
              sql += ' rm.periodo_id = ?';
            } else {
              sql += ' where rm.periodo_id = ?'
            }
          }

          db.executeSql(sql, data)
            .then((data: any) => {
              if (data.rows.length > 0) {
                let remedios: any[] = [];
                for (var i = 0; i < data.rows.length; i++) {
                  var remedio = data.rows.item(i);
                  remedios.push(remedio);
                }
                resolve(remedios);
              }
            })
            .catch((e) => console.error(e));
        })
        .catch((e) => console.error(e));
    });
  }

  /*
  SELECT rp.*, r.nome as nome_remedio, p.nome as nome_perido FROM 
  remediosPeriodo rp inner join periodos p on rp.periodo_id = p.id 
  inner join remedios r on rp.remedio_id = r.id
  */
  public getAllPorPeriodo(nomeRemedio: string = null, periodo: number = null) {
    return new Promise((resolve, reject) => {
      this.dbProvider.getDB()
        .then((db: SQLiteObject) => {
          let sql = 'SELECT rp.*, r.nome as nome_remedio, p.nome as nome_periodo FROM remediosPeriodo rp ' +
            ' inner join periodos p on rp.periodo_id = p.id ' +
            ' inner join remedios r on rp.remedio_id = r.id ' +
            '  ';
          var data: any[];

          // filtrando pelo nome
          if (nomeRemedio) {
            sql += ' where r.nome like ?'
            data.push('%' + nomeRemedio + '%');
          }

          if (periodo) {
            if (data.length > 0) {
              sql += ' rm.periodo_id = ?';
            } else {
              sql += ' where rm.periodo_id = ?'
            }
          }

          let remedios: any[] = [];
          let lista: any[] = [];
          db.executeSql(sql, data)
            .then((data: any) => {
              if (data.rows.length > 0) {
                let manha: any[] = [];
                let tarde: any[] = [];
                let noite: any[] = [];
                // let lista: any[];
                // let remedios: any[] = [];
                for (var i = 0; i < data.rows.length; i++) {
                  var remedio = data.rows.item(i);

                  switch (remedio.nome_periodo) {
                    case "Manhã": {
                      manha.push(remedio);
                      break;
                    }
                    case "Tarde": {
                      tarde.push(remedio);
                      break;
                    }
                    case "Noite": {
                      noite.push(remedio);
                      break;
                    }
                  }
                  // lista[remedio.nome_remedio].push(remedio); 
                  remedios.push(remedio);
                }
                if (manha.length > 0) {
                  lista.push({
                    periodo: "Manhã",
                    valores: manha
                  });
                }

                if (tarde.length > 0) {
                  lista.push({
                    periodo: "Tarde",
                    valores: tarde
                  });
                }

                if (noite.length > 0) {
                  lista.push({
                    periodo: "Noite",
                    valores: noite
                  });
                }
                resolve(lista);
              }
            })
            .catch((e) => console.error("erro for", JSON.stringify(e)));
        })
        .catch((e) => console.error("erro select", JSON.stringify(e)));
    });
  }

  public notificacao() {
    // Schedule multiple notifications
    // this.localNotifications.schedule([{
    //   id: 1,
    //   text: 'Multi ILocalNotification 1',
    //   sound: isAndroid ? 'file://sound.mp3' : 'file://beep.caf',
    //   data: { secret: key }
    // }, {
    //   id: 2,
    //   title: 'Local ILocalNotification Example',
    //   text: 'Multi ILocalNotification 2',
    //   icon: 'http://example.com/icon.png'
    // }]);


    // Schedule delayed notification
    this.localNotifications.schedule({
      title: 'Remédios',
      text: 'Aviso tomar remédios',
      // trigger: { at: new Date(new Date().getTime() + 10) },      
      // trigger: {
      //   count: 1,
      //   every: { minute: 58, seconds: 0}
      // },
      led: 'FF0000',
      vibrate: true,
      icon: 'http://example.com/icon.png',
      sound: null
    });
  }
}

export class RemediosPeriodo {
  id: number;
  remedio_id: number;
  quantidade: string;
  periodo_id: number;
}