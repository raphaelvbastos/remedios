import { Component } from '@angular/core';

import { AboutPage } from '../about/about';
import { ContactPage } from '../contact/contact';
import { PeriodosPage } from '../periodos/periodos';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = PeriodosPage;
  tab2Root = AboutPage;
  tab3Root = ContactPage;

  constructor() {

  }
}
