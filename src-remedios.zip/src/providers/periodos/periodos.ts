import { Injectable } from '@angular/core';
import { SQLiteObject } from '@ionic-native/sqlite';
import { DatabaseProvider } from '../database/database';

@Injectable()
export class PeriodosProvider {

  constructor(private dbProvider: DatabaseProvider) { }

  public insert(periodo: Periodo) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'insert into periodos (nome, hora) values (?, ?)';
        let data = [periodo.nome];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public update(periodo: Periodo) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'update periodos set nome = ?, hora = ? where id = ?';
        let data = [periodo.nome, periodo.hora, periodo.id];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public remove(id: number) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'delete from periodos where id = ?';
        let data = [id];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public get(id: number) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'select * from periodos where id = ?';
        let data = [id];

        return db.executeSql(sql, data)
          .then((data: any) => {
            if (data.rows.length > 0) {
              let item = data.rows.item(0);
              let periodo = new Periodo();
              periodo.id = item.id;
              periodo.nome = item.nome;
              periodo.hora = item.hora;

              return periodo;
            }

            return null;
          })
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  // public getJobs() {
  //   return new Promise((resolve, reject) => {
  //     this.sqlite.create({
  //       name: this.dbName,
  //       location: this.dbLoc
  //     })
  //       .then((db: SQLiteObject) => {
  //         var query = "SELECT * FROM user_jobs WHERE user_id=(?)";
  //         db.executeSql(query, [this.userId])
  //           .then((resp) => {
  //             console.log('Executed SELECT SQL:', resp.rows.length);
  //             resolve(resp);
  //           })
  //           .catch(e => console.log('db.executeSql error: ', JSON.stringify(e)));

  //       })
  //       .catch(e => console.log('sqlite.create error: ', e));

  //   });
  // }

  // this.dataProvider.getJobs().then((resp:any) => {
  //   if (resp.rows.length > 0) {
  //     for (var i = 0; i < resp.rows.length; i++) {
  //       let item = resp.rows.item(i);
  //       console.log(item);
  //     }
  //   }
  // });


  public getAll() {
    return new Promise((resolve, reject) => {
      this.dbProvider.getDB()
        .then((db: SQLiteObject) => {
          let sql = 'SELECT * FROM periodos';
          var data: any[];

          db.executeSql(sql, data)
            .then((data: any) => {
              if (data.rows.length > 0) {
                let periodos: any[] = [];
                for (var i = 0; i < data.rows.length; i++) {
                  var periodo = data.rows.item(i);
                  periodos.push(periodo);
                }
                resolve(periodos);
              } else {
                resolve([]);
              }
            }).catch(e => console.log('db.executeSql error: ', JSON.stringify(e)));
        }).catch(e => console.log('sqlite.create error: ', e));
    });
  }
}

export class Periodo {
  id: number;
  nome: string;
  hora: string;
}