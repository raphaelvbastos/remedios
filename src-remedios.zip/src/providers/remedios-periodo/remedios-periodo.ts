import { Injectable } from '@angular/core';
import { SQLiteObject } from '@ionic-native/sqlite';
import { DatabaseProvider } from '../database/database';

@Injectable()
export class RemediosPeriodoProvider {

  constructor(private dbProvider: DatabaseProvider) { }

  public insert(remediosPeriodo: RemediosPeriodo) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'insert into remediosPeriodo (remedio_id, quantidade, periodo_id) values (?, ?, ?)';
        let data = [remediosPeriodo.remedio_id, remediosPeriodo.quantidade, remediosPeriodo.periodo_id];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public update(remediosPeriodo: RemediosPeriodo) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'update remediosPeriodo set remedio_id = ?, quantidade = ?, periodo_id = ? where id = ?';
        let data = [remediosPeriodo.remedio_id, remediosPeriodo.quantidade, remediosPeriodo.periodo_id, remediosPeriodo.id];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public remove(id: number) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'delete from remediosPeriodo where id = ?';
        let data = [id];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public get(id: number) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'SELECT rp.*, r.nome as nome_remedio, p.nome as nome_perido FROM remediosPeriodos rp '+
                   ' inner join periodos p on rm.periodo_id = p.id ' +
                   ' inner join remedios r on rm.remedio_id = r.id ' +
                   ' where rp.id = ?';
        let data = [id];

        return db.executeSql(sql, data)
          .then((data: any) => {
            if (data.rows.length > 0) {
              let item = data.rows.item(0);
              let remedioPeriodo = new RemediosPeriodo();
              remedioPeriodo.id = item.id;
              remedioPeriodo.remedio_id = item.remedio_id;
              remedioPeriodo.quantidade = item.quantidade;
              remedioPeriodo.periodo_id = item.periodo_id;
              return remedioPeriodo;
            }
            return null;
          })
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public getAll(nomeRemedio: string = null, periodo: number = null) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'SELECT rp.*, r.nome as nome_remedio, p.nome as nome_perido FROM remediosPeriodos rp '+
                   ' inner join periodos p on rm.periodo_id = p.id ' +
                   ' inner join remedios r on rm.remedio_id = r.id ' +
                   '  ';
        var data: any[];

        // filtrando pelo nome
        if (nomeRemedio) {
          sql += ' where r.nome like ?'
          data.push('%' + nomeRemedio + '%');
        }

        if(periodo) {
          if(data.length > 0) {
            sql += ' rm.periodo_id = ?';
          } else {
            sql += ' where rm.periodo_id = ?'
          }
        }

        return db.executeSql(sql, data)
          .then((data: any) => {
            if (data.rows.length > 0) {
              let remedios: any[] = [];
              for (var i = 0; i < data.rows.length; i++) {
                var remedio = data.rows.item(i);
                remedios.push(remedio);
              }
              return remedios;
            } else {
              return [];
            }
          })
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }
}

export class RemediosPeriodo {
  id: number;
  remedio_id: number;
  quantidade: string;
  periodo_id: number;
}