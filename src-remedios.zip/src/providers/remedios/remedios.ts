import { Injectable } from '@angular/core';
import { SQLiteObject } from '@ionic-native/sqlite';
import { DatabaseProvider } from '../database/database';

@Injectable()
export class RemediosProvider {

  constructor(private dbProvider: DatabaseProvider) { }

  public insert(remedio: Remedio) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'insert into remedios (nome) values (?)';
        let data = [remedio.nome];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public update(remedio: Remedio) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'update remedios set nome = ? where id = ?';
        let data = [remedio.nome, remedio.id];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public remove(id: number) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'delete from remedios where id = ?';
        let data = [id];

        return db.executeSql(sql, data)
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public get(id: number) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'select * from remedios where id = ?';
        let data = [id];

        return db.executeSql(sql, data)
          .then((data: any) => {
            if (data.rows.length > 0) {
              let item = data.rows.item(0);
              let remedio = new Remedio();
              remedio.id = item.id;
              remedio.nome = item.nome;
              return remedio;
            }

            return null;
          })
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }

  public getAll(nome: string = null) {
    return this.dbProvider.getDB()
      .then((db: SQLiteObject) => {
        let sql = 'SELECT * FROM remedios';
        var data: any[];

        // filtrando pelo nome
        if (nome) {
          sql += ' where nome like ?'
          data.push('%' + nome + '%');
        }

        return db.executeSql(sql, data)
          .then((data: any) => {
            if (data.rows.length > 0) {
              let remedios: any[] = [];
              for (var i = 0; i < data.rows.length; i++) {
                var remedio = data.rows.item(i);
                remedios.push(remedio);
              }
              return remedios;
            } else {
              return [];
            }
          })
          .catch((e) => console.error(e));
      })
      .catch((e) => console.error(e));
  }
}

export class Remedio {
  id: number;
  nome: string;
}